# EY Consulting Pack

Self-contained skill pack for building client deliverables: branded
PowerPoint decks and interactive HTML sites, restylable per client via brand
kits, with Tufte-grounded charts. Assembled 2026-07-01 from
the agent-skills repo.

## Contents

| Skill | Role |
|-------|------|
| ey-brand-kit | Per-client brand kits, .pptx theme extraction, kit→CSS, design rules (start here) |
| ey-deck | Storyline-first consulting decks + pattern library + template library |
| ey-deck-review | Partner-style red-pen review: storyline, design rules, AI tells, charts |
| ey-site | Kit-styled zero-dependency interactive HTML deliverables |
| ey-synthesis | Interview/workshop material → evidence-backed findings → deck outline |
| excel-to-evidence | Workbook → tied-out, traceable exhibits with evidence log |
| xlsx | Spreadsheet read/edit/create machinery used by excel-to-evidence |
| pptx | Low-level .pptx read/edit/create machinery used by ey-deck |
| frontend-slides | HTML presentation techniques used by ey-site |
| humanizer | AI writing-register detection (design rule 25's authority) |
| orchestrate-tufte-vdqi / render-tufte-chart / assess-graphical-excellence | Chart toolkit (route / build / QA) |
| management-consulting | 42 strategic frameworks — the reasoning layer upstream of deliverables |
| meeting-minutes | Strict minutes schema (decisions w/ rationale, owned+dated actions) |
| brand-review / design-critique / ux-copy | Voice governance, visual critique, microcopy QA |
| internal-comms | Status reports, 3P updates, leadership communications |
| financial-analyst / senior-pm | Financial modeling tools; portfolio/program management |
| startup-competitors | Three-wave competitive intelligence with confidence labels |
| refero-design-research | Evidence-based design craft guides (optional Refero MCP) |

## Install

Each folder is a standard Agent Skill (SKILL.md + resources). Options:

- **Claude Code, per-repo:** copy the folders into `<repo>/.claude/skills/`.
- **Claude Code, personal:** copy into `~/.claude/skills/`.
- **Codex or other agents:** keep the folders anywhere in the workspace and
  point the agent at them (e.g. in AGENTS.md: "for decks, follow
  skills/ey-deck/SKILL.md"), or use the tool's own skills directory.

Scripts are Python 3 stdlib only — no pip installs needed for the EY skills.
The pptx and Tufte skills list their own requirements in their SKILL.md
files (e.g. LibreOffice for thumbnails, Node/pptxgenjs for from-scratch
generation).

## First tasks after install

1. Refresh `ey-brand-kit/kits/ey-default.json` from your brand-standards MCP
   server (the bundled kit is a public-information placeholder).
2. Add a real EY .pptx template, set `pptx.templatePath`, and run
   `ey-brand-kit/scripts/extract_kit.py` on it to fill the layout map.
3. Start flagging good slides into `ey-deck/library/` so the template
   library compounds.

## Licenses

- ey-brand-kit / ey-deck / ey-site: created for this repo, no restrictions.
- pptx / xlsx: (c) Anthropic, governed by your Anthropic agreement (see
  their LICENSE.txt files) — intended for use with Anthropic services.
- frontend-slides: MIT (Zara Zhang).
- Tufte skills: see their folders; render-tufte-chart bundles MIT-licensed
  tufte-css.
- Imported consulting stack: each folder carries its upstream LICENSE
  (Anthropic knowledge-work-plugins, anthropics/skills, github/awesome-copilot,
  borghei/Claude-Skills, ferdinandobons/startup-skill,
  gcamilo/management-consulting, referodesign/refero_skill — all MIT or
  equivalent permissive).

Client templates, logos, and kits you add are confidential — keep the
destination repo private.

## Keeping skills in sync across Codex and Claude

Make the repo this pack was unzipped into the single source of truth; every
tool reads the same local clone. Edits from any agent: commit → push; other
sessions pick it up at next start.

1. Clone the repo once per machine, e.g. to `~/skills`.
2. Claude Code — symlink skills in:

   ```bash
   mkdir -p ~/.claude/skills
   for d in ~/skills/*/; do ln -sfn "$d" ~/.claude/skills/$(basename "$d"); done
   ```

3. Auto-pull at session start (Claude Code `settings.json`):

   ```json
   {
     "hooks": {
       "SessionStart": [
         { "hooks": [ { "type": "command",
             "command": "git -C ~/skills pull --ff-only --quiet || true" } ] }
       ]
     }
   }
   ```

4. Codex — pull on every launch via a shell wrapper, plus an AGENTS.md line
   as backup:

   ```bash
   codex() { git -C ~/skills pull --ff-only --quiet 2>/dev/null; command codex "$@"; }
   ```

5. Cursor — generate native Project Rules that trigger like skills do
   (one thin .mdc stub per skill, description-matched by Cursor's agent,
   pointing at the real SKILL.md):

   ```bash
   python tools/make_cursor_rules.py            # writes ./cursor-rules/
   mkdir -p <workspace>/.cursor/rules && cp cursor-rules/*.mdc <workspace>/.cursor/rules/
   ```

   Re-run after adding or re-describing skills. Cursor also reads AGENTS.md,
   so the trigger index below works there as a fallback.

## How agents know when to use these skills

Claude Code auto-discovers skills from their frontmatter descriptions — just
talk ("build me a readout deck", "I like this slide — save it"). Codex needs
a trigger index in each workspace's AGENTS.md (adjust the path):

```markdown
## Skills (~/skills) — read the matching SKILL.md BEFORE starting these tasks
- Any deck/slides/presentation/readout → ~/skills/ey-deck/SKILL.md
- User praises/flags a slide or deck ("save this", "I like the aesthetic/
  headlines") → ~/skills/ey-deck/SKILL.md (template library section)
- Client branding, extract template, restyle for client → ~/skills/ey-brand-kit/SKILL.md
- Interactive site/dashboard/web deliverable → ~/skills/ey-site/SKILL.md
- Review/QA/red-pen a deck → ~/skills/ey-deck-review/SKILL.md
- Synthesize interviews/workshop notes → ~/skills/ey-synthesis/SKILL.md
- Exhibits/charts from a workbook → ~/skills/excel-to-evidence/SKILL.md
- Strategy frameworks/problem structuring → ~/skills/management-consulting/SKILL.md
- Meeting notes → minutes → ~/skills/meeting-minutes/SKILL.md
```

## Automations

`tools/automations.md` (bundled) has three scheduled-agent recipes with
runnable commands: daily skills housekeeping, weekly library digest +
rule-promotion PRs, and the Friday correction review that turns repeated
user corrections into proposed skill/rule edits. All three end in files or
PRs — never a send.
