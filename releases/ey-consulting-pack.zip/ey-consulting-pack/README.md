# EY Consulting Pack

Self-contained skill pack for building client deliverables: branded
PowerPoint decks and interactive HTML sites, restylable per client via brand
kits, with Tufte-grounded charts. Assembled 2026-06-12 from
the agent-skills repo.

## Contents

| Skill | Role |
|-------|------|
| ey-brand-kit | Per-client brand kits, .pptx theme extraction, kit→CSS, design rules (start here) |
| ey-deck | Storyline-first consulting decks + pattern library + template library |
| ey-deck-review | Partner-style red-pen review: storyline, design rules, AI tells, charts |
| ey-site | Kit-styled zero-dependency interactive HTML deliverables |
| ey-synthesis | Interview/workshop material → evidence-backed findings → deck outline |
| excel-to-evidence | Workbook → tied-out, traceable exhibits with evidence log |
| xlsx | Spreadsheet read/edit/create machinery used by excel-to-evidence |
| pptx | Low-level .pptx read/edit/create machinery used by ey-deck |
| frontend-slides | HTML presentation techniques used by ey-site |
| humanizer | AI writing-register detection (design rule 25's authority) |
| orchestrate-tufte-vdqi / render-tufte-chart / assess-graphical-excellence | Chart toolkit (route / build / QA) |
| management-consulting | 42 strategic frameworks — the reasoning layer upstream of deliverables |
| meeting-minutes | Strict minutes schema (decisions w/ rationale, owned+dated actions) |
| brand-review / design-critique / ux-copy | Voice governance, visual critique, microcopy QA |
| internal-comms | Status reports, 3P updates, leadership communications |
| financial-analyst / senior-pm | Financial modeling tools; portfolio/program management |
| startup-competitors | Three-wave competitive intelligence with confidence labels |
| refero-design-research | Evidence-based design craft guides (optional Refero MCP) |

## Install

Each folder is a standard Agent Skill (SKILL.md + resources). Options:

- **Claude Code, per-repo:** copy the folders into `<repo>/.claude/skills/`.
- **Claude Code, personal:** copy into `~/.claude/skills/`.
- **Codex or other agents:** keep the folders anywhere in the workspace and
  point the agent at them (e.g. in AGENTS.md: "for decks, follow
  skills/ey-deck/SKILL.md"), or use the tool's own skills directory.

Scripts are Python 3 stdlib only — no pip installs needed for the EY skills.
The pptx and Tufte skills list their own requirements in their SKILL.md
files (e.g. LibreOffice for thumbnails, Node/pptxgenjs for from-scratch
generation).

## First tasks after install

1. Refresh `ey-brand-kit/kits/ey-default.json` from your brand-standards MCP
   server (the bundled kit is a public-information placeholder).
2. Add a real EY .pptx template, set `pptx.templatePath`, and run
   `ey-brand-kit/scripts/extract_kit.py` on it to fill the layout map.
3. Start flagging good slides into `ey-deck/library/` so the template
   library compounds.

## Licenses

- ey-brand-kit / ey-deck / ey-site: created for this repo, no restrictions.
- pptx / xlsx: (c) Anthropic, governed by your Anthropic agreement (see
  their LICENSE.txt files) — intended for use with Anthropic services.
- frontend-slides: MIT (Zara Zhang).
- Tufte skills: see their folders; render-tufte-chart bundles MIT-licensed
  tufte-css.
- Imported consulting stack: each folder carries its upstream LICENSE
  (Anthropic knowledge-work-plugins, anthropics/skills, github/awesome-copilot,
  borghei/Claude-Skills, ferdinandobons/startup-skill,
  gcamilo/management-consulting, referodesign/refero_skill — all MIT or
  equivalent permissive).

Client templates, logos, and kits you add are confidential — keep the
destination repo private.
